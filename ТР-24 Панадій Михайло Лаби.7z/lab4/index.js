//Task 1
let Task = {
    name: "task_1",
    about: "any info",
    start: "10:10am",
    end: "11:10pm",
};

const button = document.querySelector('.button_1');

button.onclick = function(){

    console.log("Task1:",Task);
}



//Task 2
let Project = {
    project_name: "lab_5",
    type: "laba",
    add: function (){
       this.time_days = 10;
    },

    del: function(){
        delete this.type;
    },

    change: function () {
        this.project_name = "lab 5"; 
    }
};

const button_1 = document.querySelector('.button_2');

function showRes(){
    console.log("before", Project);

    Project.change();
    Project.del();
    Project.add();
    console.log("after", Project);
}

button_1.addEventListener("click", showRes);

//Task3
let ProjectTask = Object.assign({}, Project, Task);

const both = document.querySelector('.button_3');

function task3 (){
    console.log("Task3:", ProjectTask);
}

both.addEventListener("click", task3);

//Task4
const button_4 = document.querySelector('.button_4');

Object.prototype.showData = function (){
    console.log("Task4:",Task)
}

button_4.addEventListener("click",showData);

//Task5
let TaskInProgress = Object.create(Task);
TaskInProgress.completePercent = "50%";
TaskInProgress.status = true;
TaskInProgress.showData_2 = function () {
    console.log("Hello!");
}
  function task5(){
    console.log("Task5:",TaskInProgress);
    console.log("Task5:",TaskInProgress.name);
    console.log("Task5:",TaskInProgress.about);
    console.log("Task5:",TaskInProgress.start);
    console.log("Task5:",TaskInProgress.end);
  }
  
  const button_5 = document.querySelector(".button_5");

  button_5.addEventListener("click", task5);

//Task6

class TaskClass {
    constructor(about, start, end) {
        //this._name = name;
        this.about = about;
        this.start = start;
        this.end = end;
    }

    set name(name) {
        this._name = name;
    }

    get name() {
        return this._name;
    }

    showData_3() {
        console.log("Task6:", task.name);
        console.log("Task6:", task.about);
        console.log("Task6:", task.start);
        console.log("Task6:", task.end);
    }
}

class TaskClassInProgress extends TaskClass {
    constructor(name, about, start, end) {
        super(name, about, start, end);
    }
}

const task = new TaskClassInProgress("any_info", "10:10am", "11:10pm");
task.name = "task_1";

const button_6 = document.querySelector(".button_6");

button_6.addEventListener("click", task.showData_3.bind(task));




  