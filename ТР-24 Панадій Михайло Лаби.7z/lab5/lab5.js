
const quizOptions = {
    easy: [
        { 
        question: "Яка мова програмування використовується для розробки веб-сторінок?", 
        answers: ["JavaScript", "Python", "Java"], 
        correctAnswer: "JavaScript" 
        },
        
        { 
            question: "друге легке питання", 
            answers: ["JavaScript", "Python", "Java"], 
            correctAnswer: "Java" 
        },

        { 
            question: "трете легке питання?", 
            answers: ["JavaScript", "Python", "Java"], 
            correctAnswer: "Python" 
        },

        { 
            question: "четверте легке питання?", 
            answers: ["JavaScript", "Python", "Java"], 
            correctAnswer: "Python" 
        },
    ],
    medium: [
        { 
            question: "перше середне питання", 
            answers: ["JavaScript", "Python", "Java"], 
            correctAnswer: "JavaScript" 
        },

        { 
            question: "друге середне питання?", 
            answers: ["JavaScript", "Python", "Java"], 
            correctAnswer: "JavaScript" 
        },

        { 
            question: "трете середне питання?", 
            answers: ["JavaScript", "Python", "Java"], 
            correctAnswer: "JavaScript" 
        },

        { 
            question: "четверте середне питання?", 
            answers: ["JavaScript", "Python", "Java"], 
            correctAnswer: "Python" 
        },
    ],
    hard: [
        { 
            question: "перше важке питання?", 
            answers: ["JavaScript", "Python", "Java"], 
            correctAnswer: "JavaScript" 
        },

        { 
            question: "Друге важке питання?", 
            answers: ["JavaScript", "Python", "Java"], 
            correctAnswer: "JavaScript" 
        },

        { 
            question: "Трете важке питання?", 
            answers: ["JavaScript", "Python", "Java"], 
            correctAnswer: "Java" 
        },

        { 
            question: "четверте важке питання?", 
            answers: ["JavaScript", "Python", "Java"], 
            correctAnswer: "Python" 
        },
    ]
};


let userName, userGroup;
let userAnswers = {};


function startQuiz(level) {
    const questions = quizOptions[level];
    const randomQuestions = questions.sort(() => Math.random() - 0.5);
    console.log(randomQuestions); 

    for (let i = 0; i < randomQuestions.length; i++) {
        const question = randomQuestions[i];

        const questionElement = document.createElement("div");
        questionElement.classList.add("question");
        questionElement.innerHTML = `<p>${question.question}</p>`;

        const type = i % 4; 

        if (type === 0) {
            const codeTextarea = document.createElement("textarea");
            codeTextarea.id = `question${i}`;
            codeTextarea.name = `question${i}`;
            questionElement.appendChild(codeTextarea);

        } else if (type === 1) {
            const answersList = document.createElement("ul");
            answersList.classList.add("answers");

            for (let j = 0; j < question.answers.length; j++) {
                const answerItem = document.createElement("li");
                answerItem.innerHTML = `<label><input type="checkbox" name="question${i}" value="${question.answers[j]}">${question.answers[j]}</label>`;
                answersList.appendChild(answerItem);
            }

            questionElement.appendChild(answersList);
        } else if (type === 2) {
            const dropdownSelect = document.createElement("select");
            dropdownSelect.id = `question${i}`;
            dropdownSelect.name = `question${i}`;

            for (let j = 0; j < question.answers.length; j++) {
                const option = document.createElement("option");
                option.value = question.answers[j];
                option.text = question.answers[j];
                dropdownSelect.appendChild(option);
            }

            questionElement.appendChild(dropdownSelect);
        } else if (type === 3) {
            const radioList = document.createElement("ul");
            radioList.classList.add("answers");

            for (let j = 0; j < question.answers.length; j++) {
                const radioItem = document.createElement("li");
                radioItem.innerHTML = `<label><input type="radio" name="question${i}" value="${question.answers[j]}">${question.answers[j]}</label>`;
                radioList.appendChild(radioItem);
            }

            questionElement.appendChild(radioList);
        }

        const containerId = `quizContainer${type + 1}`;
        const quizContainer = document.getElementById(containerId);
        quizContainer.appendChild(questionElement);
    }
}





function submitQuiz() {
    
    userAnswers["quizContainer1"] = document.getElementById("question0").value;
    userAnswers["quizContainer2"] = Array.from(document.querySelectorAll('input[name^="question1"]:checked')).map(checkbox => checkbox.value); 
    userAnswers["quizContainer3"] = document.getElementById("question2").value;
    userAnswers["quizContainer4"] = document.querySelector('input[name="question3"]:checked') ? document.querySelector('input[name="question3"]:checked').value : null;

    
    console.log(userAnswers);
    
    let count = 0;

    for (let difficulty in quizOptions) {
        const questions = quizOptions[difficulty];
    
        for (let i = 0; i < questions.length; i++) {
            const correctAnswer = questions[i].correctAnswer;
            const userAnswer = userAnswers[`quizContainer${i + 1}`];
    
            if (Array.isArray(userAnswer)) {
                if (arraysEqual(userAnswer, correctAnswer)) {
                    count++;
                }
            } else {
                const normalizedUserAnswer = userAnswer ? userAnswer.toLowerCase() : null;
                const normalizedCorrectAnswer = correctAnswer.toLowerCase();
    
                if (normalizedUserAnswer === normalizedCorrectAnswer) {
                    count++;
                }
            }
        }
    }

    
    console.log(`Correct answers: ${count}`);
    
}


function arraysEqual(arr1, arr2) {
    return arr1.length === arr2.length && arr1.every((value, index) => value === arr2[index]);
}



const rand = Math.floor(Math.random() * 3);
if(rand === 0){
    startQuiz('easy');
}
else if(rand === 1){
    startQuiz('medium');
}
else {
    startQuiz('hard');
}

